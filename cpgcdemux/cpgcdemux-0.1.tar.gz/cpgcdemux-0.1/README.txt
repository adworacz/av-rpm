CPGCDEMUX is a console port of PgcDemux by Jesus Soto.

It is a tool for demuxing a DVD PGC/VID/CELL in its elementary streams.

This port based on version 1.2.0.5 of original PgcDemux (see ReadmePgcDemux.txt).

Distruted under terms of LGPL 2.1+.

URL: http://cdslow.org.ru/en/cpgcdemux

Vadim Druzhin <cdslow@mail.ru>
22 December 2013
